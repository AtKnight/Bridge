SCHOPPEN = "Schoppen"
HARTEN = "Harten"
RUITEN = "Ruiten"
KLAVEREN = "Klaveren"

NOORD = 'Noord'
OOST = 'Oost'
ZUID = 'Zuid'
WEST = 'West'

ALLE_KLEUREN = (SCHOPPEN, HARTEN, RUITEN, KLAVEREN)
ALLE_WINDRICHTINGEN = (NOORD, OOST, ZUID, WEST)

HONNEURS = list('BVKA')
            # volgorde is belangrijk. Zie class Kaart

ALLE_KAARTWAARDEN = [str(n) for n in range(2, 11)] + HONNEURS
