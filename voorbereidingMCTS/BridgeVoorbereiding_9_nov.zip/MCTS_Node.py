import math
import random
import copy
from NamedTuples import State, ChildrenContent, ActionNodeValue
from Search import Search
from GespeeldeKaart import GespeeldeKaart

class MCTS_Node:
    INF = 1.0e308
    
    def __init__(self, state): 
        self.parent = None
        self.children = [] # = [ ChildrenContent=(kaart, node) ...] 
                           # action is de gespeelde Kaart die tot de node heeft geleid.
                           
        self.stateUitpakken(state)
        
        self.sumValues = state.aantalPuntenNZ
        # AANPASSEN AAN SPELER
        
        self.numberOfVisits = 0
        self.hand = self.handenDict[self.huidigeSpeler]
        self.gespeeldeKaarten = []
        self.searchMachine = Search()
        
    # -----------------------------------------------------------------------

    def calc_UCB1(self):
        # OKAY
        if (self.isRoot() or (self.numberOfVisits == 0)):
            return self.INF
    
        parentVisits = self.parent.getNumberOfVisits()
        if sparentVisits == 0:
            return self.INF

        averageValue = self.sumValues / parentVisits
        part2 = 2.0 * math.sqrt(math.log(parentVisits / self.numberOfVisits))

        return averageValue + part2
    
    # -----------------------------------------------------------------------
                                              
    def selectNode(self):
        # OKAY
        if self.isLeaf():
            return self
        else: # no leaf                
            max_UCB_Node = self._max_UCB1_Node()
            
            return max_UCB_Node.node.selectNode()
        
    # -----------------------------------------------------------------------
    
    def _max_UCB1_Node(self):
         # OKAY
        bestNode = None
        maxValue = -self.INF
        
        for child in self.children:
            tmp = child.node.calc_UCB1()
            if tmp == self.INF:
                return child
            
            if tmp > maxValue:
                maxValue = tmp
                bestNode = child
                
        return bestNode
    
    # -----------------------------------------------------------------------

    def expand(self):
        print("expand uitvoeren ")
        for card in  self.searchMachine.speelbareKaarten(self.hand, \
                                                  self.gevraagdeKleur, \
                                                  self.troef):
            """            
            print("kaarten in huidige slag: ")
            for c in self.kaartenHuidigeSlag:
                print(c.card, end = ", ")
            print()
            """
            
            self.action = card

            # voor iedere kaart moet een nieuwe state en node worden aangemaakt
            # aanpassen: handenDict, kaartenHuidigeSlag, huidigeSpeler, aantalPuntenNZ
            
            nwHandenDict = copy.deepcopy(self.handenDict)
            nwHandenDict[self.huidigeSpeler].removeCard(card)
            
            nwKaartenHuidigeSlag = copy.deepcopy(self.kaartenHuidigeSlag)
            nwKaartenHuidigeSlag.append(GespeeldeKaart(self.huidigeSpeler, card))

            
            if len(self.kaartenHuidigeSlag) == 0: # eersteKaart
                   # kaarten die in de huidige slag gespeeld zijn
                nwGevraagdeKleur = card.kleur
                self.gevraagdeKleur = card.kleur
            else:
                nwGevraagdeKleur = self.gevraagdeKleur
  
            toenamePunten = 0     
            if  len(self.kaartenHuidigeSlag) == 4: # vierdekaart:
                toenamePunten = self.searchMachine.toenameSlagen(self.troef, self.kaartenHuidigeSlag)
                toenamePunten = toenamePunten[0]
                
                nwHuidigeSpeler = self.searchMachine.volgendeSpeler[self.huidigeSpeler]
            else:
                nwHuidigeSpeler = self.huidigeSpeler
                
                
            state = State(nwHandenDict, nwHuidigeSpeler, \
                                self.troef,nwKaartenHuidigeSlag,  \
                                self.aantalPuntenNZ + toenamePunten)
            
            node = MCTS_Node(state)
            
            self.children.append(ChildrenContent(card, node)) 
            print("expand card =  ", card)
        print("Einde expand")
            
    # -----------------------------------------------------------------------
        
    def rollOut(self):
        copyHanden = copy.deepcopy(self.handenDict)
        speler = self.huidigeSpeler
          
        kaarten = self.searchMachine.speelbareKaarten(copyHanden[speler], \
                                    self.gevraagdeKleur, self.troef)
        
        if (len(kaarten) == 0):
            return 
        
        print("rollOut speelbareKaarten:")
        for k in kaarten:
            print(k, end = ', ')
        print("")
        
        #selecteer een random action
        index = random.randint(0, len(kaarten) - 1)
        kaart = kaarten[index]
        
        copyHanden[speler].removeCard(kaart)
        
        tmp = random.randint(-3, 4)
        print("rollOut geselecteerd: ", str(kaart), " geschatte waarde ", tmp)
        
        speler = self.searchMachine.volgendeSpeler[speler]
        """ 
            -eerste kaart  --> kleur/troef
            -laatste kaart --> update aantalpunten
                volgendespeler = winaar
              anders volgendespeler = nexPlayer(huidigeSpeler)
            -verwijder randomKaart
        """
        
        #return self.aantalBehaaldeSlaagen
        
        print("rollOut moet nog recursief verder zoeken")
        return tmp
    
    # -----------------------------------------------------------------------

    def backPropagate(self, value):
        # OKAY 
        self.sumValues += value
        self.numberOfVisits += 1

        if not self.isRoot():
            self.parent.backPropagate(value)
            
        print("einde backPropagate ", value)
      
     
    # -----------------------------------------------------------------------    

    def getNumberOfVisits(self):
        # OKAY
        return self.numberOfVisits
    
    # -----------------------------------------------------------------------
    
    def getBestchildAndValue(self): # (action, node, value)
        bestTrio = None 
        
        for child in self.children:
            if bestTrio == None:
               bestTrio = ActionNodeValue(child.kaart, child.node, child.node.calc_UCB1()) 
            else:
                tmp = child.node.calc_UCB1()
                if tmp > bestTrio.value :
                    bestTrio = ActionNodeValue(child.action, child.node, tmp)
                    
        return bestTrio
    
    # -----------------------------------------------------------------------
    
    def showNextAction(self):
        bestTrio = self.getBestchildAndValue()
        
        if bestTrio != None:
            print("actie = ", bestTrio.action, " value = ", bestTrio.value)
        
            if bestTrio.node != None:
                bestTrio.node.showNextAction()

    # -----------------------------------------------------------------------
    
    def stateUitpakken(self, state) :
        self.handenDict = state.handenDict
        self.huidigeSpeler = state.huidigeSpeler
        self.troef = state.troef
        self.kaartenHuidigeSlag = state.kaartenHuidigeSlag
        self.aantalKaartenInSlag = len(self.kaartenHuidigeSlag)
        
        if self.aantalKaartenInSlag == 0:
            self.gevraagdeKleur = None
        else:
            self.gevraagdeKleur = self.kaartenHuidigeSlag[0].card.kleur
    
        self.aantalPuntenNZ = state.aantalPuntenNZ
        
    # -----------------------------------------------------------------------
    
    def getFirstChildeNode(self):
        return self.children[0]
    
     # -----------------------------------------------------------------------
    
    def toonAlles(self, index):
        print("Node index: ", index)
        print(self) 
        for x in self.children:
            print("op niveau ", index, x.kaart)
            print(self)
            x.node.toonAlles(index + 1)
    
    # -----------------------------------------------------------------------

    def isRoot(self) :
        # OKAY
        return self.parent == None
    
    # -----------------------------------------------------------------------

    def isLeaf(self):
        # OKAY
        return len(self.children ) == 0

    # -----------------------------------------------------------------------
    
    def __str__(self):
        return f"MCTS_Node: aantal children: {len(self.children)} sumValues = {self.sumValues } numberOfVisits = {self.numberOfVisits }"
