import math
import random
import copy
from NamedTuples import State, ChildrenContent, ActionNodeValue
from Search import Search

class MCTS_Node:
    INF= 1.0e308
    
    def __init__(self, state): 
        self.parent = None
        self.children = [] # = [ ChildrenContent=(kaart, node) ...] 
                           # action is de gespeelde Kaart die tot de node heeft geleid.
                           
        self.stateUitpakken(state)
        
        self.sumValues = state.aantalPuntenNZ
        # AANPASSEN AAN SPELER
        
        self.numberOfVisits = 0
        self.hand = self.handenDict[self.huidigeSpeler]
        self.gespeeldeKaarten = []
        self.searchMachine = Search()
        
    # -----------------------------------------------------------------------

    def calc_UCB1(self):
        # OKAY
        if (self.isRoot() or (self.numberOfVisits == 0)):
            return self.INF
    
        parentVisits = self.parent.getNumberOfVisits()
        if self.parent.getNumberOfVisits() == 0:
            return self.INF

        averageValue = self.sumValues / parentVisits
        part2 = 2.0 * math.sqrt(math.log(parentVisits / self.numberOfVisits))

        return averageValue + part2
    
    # -----------------------------------------------------------------------
                                              
    def selectNode(self):
        # OKAY
        print("entree select", end=' ')
        if self.isLeaf():
            print("leaf")
            return self
        else: # no leaf  
            print("no leaf")                 
            max_UCB_Node = self.max_UCB1_Node()
            
            return max_UCB_Node.node.selectNode()
    
    # -----------------------------------------------------------------------

    def expand(self):
        print("expand uitvoeren ")
        for card in  self.searchMachine.speelbareKaarten(self.hand, \
                                                  self.gevraagdeKleur, \
                                                  self.troef):
            self.action = card
            if len(self.kaartenHuidigeSlag) == 0: # eersteKaart
                self.gevraagdeKleur = card.kleur
             
            toenamePunten = 0    
            print("bestaat ? ", self.gespeeldeKaarten)
            if  len(self.kaartenHuidigeSlag) == 4: # vierdekaart:
                toenamePunten = self.toenameSlagen(self, self.troef, \
                                                   self.gespeeldeKaarten)
                self.huidigeSpeler = self.searchMachine \
                                         .volgendeSpeler(self.huidigeSpeler)
                
        
            state = State(self.handenDict, self.huidigeSpeler, \
                                self.troef,[],  \
                                self.aantalPuntenNZ + toenamePunten)
            
            node = MCTS_Node(state)
            
            self.children.append(ChildrenContent(card, node)) 
            print("expand-- ", card)
            
    # -----------------------------------------------------------------------
        
    def rollOut(self, numberOfNodes): 
        copyHanden = copy.deepcopy(self.handenDict)
        speler = self.huidigeSpeler
        
        print("rollOut: numberOfNodes = ", numberOfNodes)
        
        for i in range(0, numberOfNodes - 1): 
            kaarten = self.searchMachine.speelbareKaarten(copyHanden[speler], \
                                        self.gevraagdeKleur, self.troef)
            
            for k in kaarten:
                print(k, end = ', ')
            print(" i = ", i, " lengte = ", len(kaarten))
            
            
            #selecteer een random action
            index = random.randint(0, len(kaarten) - 1)
            kaart = kaarten[index]
            copyHanden[speler].removeCard(kaart)
            
            print("rollOut geselecteerd: ", str(kaart))
            
            speler = self.searchMachine.volgendeSpeler[speler]
            """ 
                -eerste kaart  --> kleur/troef
                -laatste kaart --> update aantalpunten
                    volgendespeler = winaar
                  anders volgendespeler = nexPlayer(huidigeSpeler)
                -verwijder randomKaart
            """
        #return self.aantalBehaaldeSlaagen
        return random.randint(-3, 4)
    
    # -----------------------------------------------------------------------

    def backPropagate(self, value):
        # OKAY 
        self.sumValues += value
        self.numberOfVisits += 1

        if not self.isRoot():
            self.parent.backPropagate(value)
      
    # -----------------------------------------------------------------------
    
    # OKAY
    def max_UCB1_Node(self):
        bestNode = None
        maxValue = -self.INF
        
        for child in self.children:
            tmp = child.node.calc_UCB1()
            if tmp == self.INF:
                return child
            
            if tmp > maxValue:
                maxValue = tmp
                bestNode = child
                
        return bestNode
     
    # -----------------------------------------------------------------------    

    def getNumberOfVisits(self):
        # OKAY
        return self.numberOfVisits
    
    # -----------------------------------------------------------------------
    
    def getBestchildAndValue(self): # (action, node, value)
        bestTrio = None 
        
        for child in self.children:
            if bestTrio == None:
               bestTrio = ActionNodeValue(child.kaart, child.node, child.node.calc_UCB1()) 
            else:
                tmp = child.node.calc_UCB1()
                if tmp > bestTrio.value :
                    bestTrio = (child.action, child.node, tmp)
                    
        return bestTrio
    
    # -----------------------------------------------------------------------
    
    def showNextAction(self):
        bestTrio = self.getBestchildAndValue()
        
        if bestTrio != None:
            print("actie = ", bestTrio.action, " value = ", bestTrio.value)
        
            if bestTrio.node != None:
                bestTrio.node.showNextAction()

    # -----------------------------------------------------------------------
    
    def stateUitpakken(self, state) :
        self.handenDict = state.handenDict
        self.huidigeSpeler = state.huidigeSpeler
        self.troef = state.troef
        self.kaartenHuidigeSlag = state.kaartenHuidigeSlag
        self.aantalKaartenInSlag = len(self.kaartenHuidigeSlag)
        
        if self.aantalKaartenInSlag == 0:
            self.gevraagdeKleur = None
        else:
            self.gevraagdeKleur = self.kaartenHuidigeSlag[0].card.kleur
    
        self.aantalPuntenNZ = state.aantalPuntenNZ
        
    # -----------------------------------------------------------------------
    
    def getFirstChildeNode(self):
        return self.children[0]
    
    # -----------------------------------------------------------------------

    def isRoot(self) :
        # OKAY
        return self.parent == None
    
    # -----------------------------------------------------------------------

    def isLeaf(self):
        # OKAY
        return len(self.children ) == 0

    # -----------------------------------------------------------------------
    
    def __str__(self):
        return f"MCTS_Node: aantal children: {len(self.children)} sumValues = {self.sumValues } numberOfVisits = {self.numberOfVisits }"
