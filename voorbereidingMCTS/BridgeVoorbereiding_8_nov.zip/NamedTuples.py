from collections import namedtuple

State           = namedtuple("State", "handenDict huidigeSpeler troef kaartenHuidigeSlag aantalPuntenNZ")
ChildrenContent = namedtuple("ChildrenContent", "kaart node")
ActionNodeValue = namedtuple("ActionNodeValue", "action node value")