from NamedTuples import State

import Constantes

from Deck import Deck
from MCTS import MCTS

if  __name__ == "__main__":        
    deck = Deck()
    deck.leesHanden()
     
    # kaartenHuidigeSlag = [gespeeldeKaarten, ...]
    state = State(deck.handenDict, Constantes.NOORD, None, [], 0)
    
    mcts = MCTS(state)
    print("deck bevat ", deck.getNumberOfCards(), " aantal kaarten")
    mcts.search(deck.getNumberOfCards())
    mcts.showResult()