from MCTS_Node import MCTS_Node

class MCTS:
   
    def __init__(self, state):
        # State = namedtuple("State", "handenDict huidigeSpeler troef kaartenHuidigeSlag aantalPuntenNZ")    

        self.rootNode = MCTS_Node(state)
        
    # -----------------------------------------------------------------------
    
    def search(self, numberOfIterations):   
        for i in range(0, numberOfIterations):
            node = self.rootNode.selectNode()
            
            print("Na selectNode Node = ", node)
            
            if node.numberOfVisits != 0:
                 node.expand()
                 print("Na expand Node = ", node)
                 node = node.getFirstChildeNode() 
                 node = node.node
                 
            node.backPropagate(node.rollOut(numberOfIterations - i))
                 
    # -----------------------------------------------------------------------
  
    def showResult(self):
        bestTrio = self.rootNode.getBestchildAndValue()
        print("Best action ", bestTrio.action)
        print("Value best action ", bestTrio.node)
        print("Best variant: ")
        
        print("showResult: ", self.rootNode)
        
        if self.rootNode != None:
            self.rootNode.showNextAction()