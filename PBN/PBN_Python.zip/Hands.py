

class Hands:
    def __init__(self):
        self.hands = []

    def addHand(self, hand):
        self.hands.append(hand)