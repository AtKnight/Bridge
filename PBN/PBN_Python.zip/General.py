import sys

def fatal_error(msg):
    print(msg)
    sys.exit(1)